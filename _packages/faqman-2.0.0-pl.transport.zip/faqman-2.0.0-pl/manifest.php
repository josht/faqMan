<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9449f54a31bb6bea85a0b7cb9a401742',
      'native_key' => 'faqman',
      'filename' => 'modNamespace/637ca5aa68e7f95c7e4182694789f425.vehicle',
      'namespace' => 'faqman',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'bed12cb0b73455c3fa9818d50e5dd370',
      'native_key' => 1,
      'filename' => 'modCategory/4f46c5f80e2236d286eded436edf100f.vehicle',
      'namespace' => 'faqman',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bacfd438d05e549e5ebc585e4af9f444',
      'native_key' => 'faqman.use_richtext',
      'filename' => 'modSystemSetting/95798f8d3e2f9ce2c2f0903512c2aace.vehicle',
      'namespace' => 'faqman',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5637534e875f72c343bb4bf2139bd7d9',
      'native_key' => 'faqman',
      'filename' => 'modMenu/c156e21c750f11218ae8d47f1f770155.vehicle',
      'namespace' => 'faqman',
    ),
  ),
);