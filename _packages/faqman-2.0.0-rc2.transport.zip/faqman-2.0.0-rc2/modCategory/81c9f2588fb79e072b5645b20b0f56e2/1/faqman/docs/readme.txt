--------------------
FAQ Manager
--------------------
Author: Josh Tambunga <josh+faqman@joshsmind.com>
--------------------

An FAQ Manager for MODx Revolution.

View the quick start on GitHub: http://github.com/josht/faqMan/

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/josht/faqMan/issues


--------------------
Copyright Information

faqMan is distributed as GPL.

faqMan was built using the
handy modExtra (https://github.com/splittingred/modExtra)
created by splittingred(Shaun McCormick).